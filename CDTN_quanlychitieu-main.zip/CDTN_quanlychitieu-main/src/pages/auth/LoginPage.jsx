// pages/auth/LoginPage.jsx
// Trang đăng nhập với glassmorphism design

import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import toast from 'react-hot-toast';
import { Eye, EyeOff, TrendingUp, Mail, Lock } from 'lucide-react';
import { loginApi } from '../../api/authApi';
import useAuthStore from '../../store/authStore';
import Button from '../../components/ui/Button';

const schema = yup.object({
  email:    yup.string().email('Email không hợp lệ').required('Vui lòng nhập email'),
  password: yup.string().min(6, 'Mật khẩu ít nhất 6 ký tự').required('Vui lòng nhập mật khẩu'),
});

const LoginPage = () => {
  const [showPass, setShowPass] = useState(false);
  const { login }               = useAuthStore();
  const navigate                = useNavigate();
  const location                = useLocation();
  const from                    = location.state?.from?.pathname || '/dashboard';

  const {
    register, handleSubmit, formState: { errors, isSubmitting },
  } = useForm({ resolver: yupResolver(schema) });

  const onSubmit = async (data) => {
    try {
      const { user, token } = await loginApi(data);
      login(user, token);
      toast.success(`Chào mừng trở lại, ${user.name}! 👋`);
      navigate(from, { replace: true });
    } catch (err) {
      toast.error(err.message || 'Đăng nhập thất bại');
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left panel – gradient background */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary-700 via-primary-600 to-primary-500 relative overflow-hidden flex-col items-center justify-center p-12">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-20 -left-20 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-primary-900/30 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-white/5 rounded-full blur-2xl" />
        </div>

        <div className="relative z-10 text-white text-center max-w-md">
          <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center mx-auto mb-6">
            <TrendingUp className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold mb-3">FinanceAI</h1>
          <p className="text-primary-100 text-lg mb-8">Quản lý chi tiêu thông minh với AI</p>

          <div className="space-y-4">
            {[
              { icon: '📊', text: 'Theo dõi thu chi real-time' },
              { icon: '🤖', text: 'AI phân tích và tư vấn tài chính' },
              { icon: '📈', text: 'Báo cáo thống kê chi tiết' },
              { icon: '🎯', text: 'Đặt ngân sách và nhắc nhở' },
            ].map(({ icon, text }) => (
              <div key={text} className="flex items-center gap-3 text-primary-100">
                <span className="text-2xl">{icon}</span>
                <span>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel – login form */}
      <div className="flex-1 flex items-center justify-center px-6 py-12 bg-slate-50 dark:bg-dark-900">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-8 h-8 rounded-xl bg-primary-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-bold text-slate-800 dark:text-white">FinanceAI</span>
          </div>

          <div className="bg-white dark:bg-dark-800 rounded-3xl shadow-card-lg p-8">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-1">
                Đăng nhập
              </h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm">
                Chưa có tài khoản?{' '}
                <Link to="/register" className="text-primary-600 font-semibold hover:underline">
                  Đăng ký ngay
                </Link>
              </p>
            </div>

            {/* Demo credentials hint */}
            <div className="mb-6 p-3 rounded-xl bg-primary-50 dark:bg-primary-900/20 border border-primary-100 dark:border-primary-800">
              <p className="text-xs text-primary-700 dark:text-primary-300 font-medium">
                🔑 Demo: <span className="font-mono">an.nguyen@email.com</span> / <span className="font-mono">123456</span>
              </p>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    placeholder="ten@email.com"
                    {...register('email')}
                    className={`input-base pl-9 ${errors.email ? 'border-expense-400 focus:ring-expense-500/30' : ''}`}
                  />
                </div>
                {errors.email && <p className="mt-1 text-xs text-expense-600">{errors.email.message}</p>}
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    Mật khẩu
                  </label>
                  <a href="#" className="text-xs text-primary-600 hover:underline">Quên mật khẩu?</a>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type={showPass ? 'text' : 'password'}
                    placeholder="••••••••"
                    {...register('password')}
                    className={`input-base pl-9 pr-10 ${errors.password ? 'border-expense-400 focus:ring-expense-500/30' : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {errors.password && <p className="mt-1 text-xs text-expense-600">{errors.password.message}</p>}
              </div>

              <Button
                type="submit"
                fullWidth
                loading={isSubmitting}
                size="lg"
                className="mt-6"
              >
                Đăng nhập
              </Button>
            </form>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-100 dark:border-slate-700" />
              </div>
              <div className="relative flex justify-center text-xs text-slate-400">
                <span className="px-3 bg-white dark:bg-dark-800">hoặc tiếp tục với</span>
              </div>
            </div>

            <button className="w-full flex items-center justify-center gap-3 py-2.5 px-4 border border-slate-200 dark:border-slate-600 rounded-xl text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              <img src="https://www.google.com/favicon.ico" alt="Google" className="w-4 h-4" />
              Google
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
